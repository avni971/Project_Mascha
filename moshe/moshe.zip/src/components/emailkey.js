import{ init } from 'emailjs-com';

init("user_zNfO8cPQT80umB3KCdmPj");


export default {
    USER_ID: `user_zNfO8cPQT80umB3KCdmPj`, //userID
    TEMPLATE_ID: `hexpower_temp`,         //templateID
    }


// console.log(e);
// e.preventDefault(); // Prevents default refresh by the browser
// emailjs.sendForm(`gmail`, apiKey.TEMPLATE_ID, e.target, apiKey.USER_ID)
// .then((result) => {
// alert("Message Sent, We will get back to you shortly", result.text);
// },
// (error) => {
// alert("An error occurred, Please try again", error.text);
// });
