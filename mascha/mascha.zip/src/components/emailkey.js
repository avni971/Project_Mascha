import{ init } from 'emailjs-com';

init("user_zNfO8cPQT80umB3KCdmPj");


export default {
    USER_ID: `user_zNfO8cPQT80umB3KCdmPj`, //userID
    TEMPLATE_ID: `hexpower_temp`,         //templateID
    }